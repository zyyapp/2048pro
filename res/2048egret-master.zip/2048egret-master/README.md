2048egret
=========

egret+puremvc

教程请参考 [这里](https://github.com/f111fei/2048egret/blob/master/%E4%BD%BF%E7%94%A8egret%E5%BC%80%E5%8F%912048.md)

[点我预览](http://xzper.com/project/2048egret/)
