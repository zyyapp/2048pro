

module game {

	export class AppConfig{
		public constructor(){
		}
	}
}