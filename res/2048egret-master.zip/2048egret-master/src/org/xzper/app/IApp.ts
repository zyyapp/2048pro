

module game {

	export interface IApp{
		enter():void;
		destroy():void;
	}
}